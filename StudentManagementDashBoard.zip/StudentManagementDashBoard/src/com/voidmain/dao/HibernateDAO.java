package com.voidmain.dao;

import java.util.List;

import com.voidmain.pojo.Assignment;
import com.voidmain.pojo.Assignment_Result;
import com.voidmain.pojo.Attendance;
import com.voidmain.pojo.CourseVideos;
import com.voidmain.pojo.ExtraCircularActivity;
import com.voidmain.pojo.InternShip;
import com.voidmain.pojo.Login;
import com.voidmain.pojo.Mentor;
import com.voidmain.pojo.Message;
import com.voidmain.pojo.Notification;
import com.voidmain.pojo.Project;
import com.voidmain.pojo.SemResult;
import com.voidmain.pojo.Skill;
import com.voidmain.pojo.Student;
import com.voidmain.pojo.Syllabus;

public class HibernateDAO {

	public static String isValidUser(String username,String password)
	{
		String role="";
		
		System.out.println("Logins:"+username+"\t"+password);
		
		Login login=getLoginById(username);

		if(login!=null && login.getPassword().equals(password))
		{
			role=login.getRole();
		}
		
		System.out.println("Role:"+role);
		
		return role;
	}

	public static boolean isUserRegistred(String username)
	{
		boolean isRegistred=false;

		for(Login login : getLogins())
		{
			System.out.println("Logins:"+login.getUsername()+"\t"+login.getPassword());
			if(login.getUsername().toLowerCase().equals(username.toLowerCase()))
			{
				isRegistred=true;

				break;
			}
		}

		return isRegistred;
	}

	//================================================================================

	public static Login getLoginById(String username)
	{
		System.out.println("username:"+username);
		
		return (Login)HibernateTemplate.getObject(Login.class,username);
	}

	public static int deleteLogin(String username)
	{
		return HibernateTemplate.deleteObject(Login.class,username);
	}

	public static List<Login> getLogins()
	{
		List<Login> logins=(List)HibernateTemplate.getObjectListByQuery("From Login");

		return logins;
	}

	//============================================================================

	public static Mentor getMentorById(String username)
	{
		return (Mentor)HibernateTemplate.getObject(Mentor.class,username);
	}

	public static int deleteMentor(String username)
	{
		return HibernateTemplate.deleteObject(Mentor.class,username);
	}

	public static List<Mentor> getMentors()
	{
		List<Mentor> mentors=(List)HibernateTemplate.getObjectListByQuery("From Mentor");

		return mentors;
	}

	//================================================================================

	public static Attendance getAttendanceById(int id)
	{
		return (Attendance)HibernateTemplate.getObject(Attendance.class,id);
	}

	public static int deleteAttendance(int id)
	{
		return HibernateTemplate.deleteObject(Attendance.class,id);
	}

	public static List<Attendance> getAttendances()
	{
		List<Attendance> attendances=(List)HibernateTemplate.getObjectListByQuery("From Attendance");

		return attendances;
	}

	//================================================================================

	public static ExtraCircularActivity getExtraCircularActivityById(int id)
	{
		return (ExtraCircularActivity)HibernateTemplate.getObject(ExtraCircularActivity.class,id);
	}

	public static int deleteExtraCircularActivity(int id)
	{
		return HibernateTemplate.deleteObject(ExtraCircularActivity.class,id);
	}

	public static List<ExtraCircularActivity> getExtraCircularActivitys()
	{
		List<ExtraCircularActivity> extraCircularActivitys=(List)HibernateTemplate.getObjectListByQuery("From ExtraCircularActivity");

		return extraCircularActivitys;
	}

	//================================================================================

	public static InternShip getInternShipById(int id)
	{
		return (InternShip)HibernateTemplate.getObject(InternShip.class,id);
	}

	public static int deleteInternShip(int id)
	{
		return HibernateTemplate.deleteObject(InternShip.class,id);
	}

	public static List<InternShip> getInternShips()
	{
		List<InternShip> internShips=(List)HibernateTemplate.getObjectListByQuery("From InternShip");

		return internShips;
	}

	//================================================================================

	public static Project getProjectById(int id)
	{
		return (Project)HibernateTemplate.getObject(Project.class,id);
	}

	public static int deleteProject(int id)
	{
		return HibernateTemplate.deleteObject(Project.class,id);
	}

	public static List<Project> getProjects()
	{
		List<Project> projects=(List)HibernateTemplate.getObjectListByQuery("From Project");

		return projects;
	}

	//================================================================================

	public static SemResult getSemResultById(int id)
	{
		return (SemResult)HibernateTemplate.getObject(SemResult.class,id);
	}

	public static int deleteSemResult(int id)
	{
		return HibernateTemplate.deleteObject(SemResult.class,id);
	}

	public static List<SemResult> getSemResults()
	{
		List<SemResult> semResults=(List)HibernateTemplate.getObjectListByQuery("From SemResult");

		return semResults;
	}

	//================================================================================

	public static Skill getSkillById(String id)
	{
		return (Skill)HibernateTemplate.getObject(Skill.class,id);
	}

	public static int deleteSkill(int id)
	{
		return HibernateTemplate.deleteObject(Skill.class,id);
	}

	public static List<Skill> getSkills()
	{
		List<Skill> skills=(List)HibernateTemplate.getObjectListByQuery("From Skill");

		return skills;
	}

	//================================================================================

	public static Student getStudentById(String rno)
	{
		return (Student)HibernateTemplate.getObject(Student.class,rno);
	}

	public static int deleteStudent(String rno)
	{
		return HibernateTemplate.deleteObject(Student.class,rno);
	}

	public static List<Student> getStudents()
	{
		List<Student> students=(List)HibernateTemplate.getObjectListByQuery("From Student");

		return students;
	}

	//================================================================================

	public static Assignment_Result getAssignment_ResultById(int id)
	{
		return (Assignment_Result)HibernateTemplate.getObject(Assignment_Result.class,id);
	}

	public static int deleteAssignment_Result(int id)
	{
		return HibernateTemplate.deleteObject(Assignment_Result.class,id);
	}

	public static List<Assignment_Result> getAssignment_Results()
	{
		List<Assignment_Result> assignment_Results=(List)HibernateTemplate.getObjectListByQuery("From Assignment_Result");

		return assignment_Results;
	}

	//================================================================================
	public static Assignment getAssignmentById(int id)
	{
		return (Assignment)HibernateTemplate.getObject(Assignment.class,id);
	}

	public static int deleteAssignment(int id)
	{
		return HibernateTemplate.deleteObject(Assignment.class,id);
	}

	public static List<Assignment> getAssignments()
	{
		List<Assignment> assignments=(List)HibernateTemplate.getObjectListByQuery("From Assignment");

		return assignments;
	}

	//================================================================================
	public static CourseVideos getCourseVideosById(int id)
	{
		return (CourseVideos)HibernateTemplate.getObject(CourseVideos.class,id);
	}

	public static int deleteCourseVideos(int id)
	{
		return HibernateTemplate.deleteObject(CourseVideos.class,id);
	}

	public static List<CourseVideos> getCourseVideoss()
	{
		List<CourseVideos> courseVideoss=(List)HibernateTemplate.getObjectListByQuery("From CourseVideos");

		return courseVideoss;
	}

	//================================================================================
	public static Message getMessageById(int id)
	{
		return (Message)HibernateTemplate.getObject(Message.class,id);
	}

	public static int deleteMessage(int id)
	{
		return HibernateTemplate.deleteObject(Message.class,id);
	}

	public static List<Message> getMessages()
	{
		List<Message> messages=(List)HibernateTemplate.getObjectListByQuery("From Message");

		return messages;
	}

	//================================================================================
	public static Notification getNotificationById(int id)
	{
		return (Notification)HibernateTemplate.getObject(Notification.class,id);
	}

	public static int deleteNotification(int id)
	{
		return HibernateTemplate.deleteObject(Notification.class,id);
	}

	public static List<Notification> getNotifications()
	{
		List<Notification> notifications=(List)HibernateTemplate.getObjectListByQuery("From Notification");

		return notifications;
	}

	//================================================================================
	public static Syllabus getSyllabusById(int id)
	{
		return (Syllabus)HibernateTemplate.getObject(Syllabus.class,id);
	}

	public static int deleteSyllabus(int id)
	{
		return HibernateTemplate.deleteObject(Syllabus.class,id);
	}
	public static List<Syllabus> getSyllabuss()
	{
		List<Syllabus> syllabuss=(List)HibernateTemplate.getObjectListByQuery("From Syllabus");

		return syllabuss;
	}
}
