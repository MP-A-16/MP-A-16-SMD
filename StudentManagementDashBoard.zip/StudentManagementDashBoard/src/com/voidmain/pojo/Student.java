package com.voidmain.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {
	
	@Id
	private String rno;
	private String name;
	private String department;
	private String currentyear;
	private String section;
	private String cgpa;
	private String review;
	private String parentemail;
	
	public String getParentemail() {
		return parentemail;
	}
	public void setParentemail(String parentemail) {
		this.parentemail = parentemail;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public String getRno() {
		return rno;
	}
	public void setRno(String rno) {
		this.rno = rno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getCurrentyear() {
		return currentyear;
	}
	public void setCurrentyear(String currentyear) {
		this.currentyear = currentyear;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getCgpa() {
		return cgpa;
	}
	public void setCgpa(String cgpa) {
		this.cgpa = cgpa;
	}
	
	@Override
	public String toString() {
		return "Student [rno=" + rno + ", name=" + name + ", department=" + department + ", currentyear=" + currentyear
				+ ", section=" + section + ", cgpa=" + cgpa + ", review=" + review + ", parentemail=" + parentemail
				+ "]";
	}

}
