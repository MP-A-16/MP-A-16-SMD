package com.voidmain.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.voidmain.dao.HibernateDAO;
import com.voidmain.dao.HibernateTemplate;
import com.voidmain.pojo.Assignment;
import com.voidmain.pojo.Attendance;
import com.voidmain.pojo.CourseVideos;
import com.voidmain.pojo.ExtraCircularActivity;
import com.voidmain.pojo.InternShip;
import com.voidmain.pojo.Project;
import com.voidmain.pojo.SemResult;
import com.voidmain.pojo.Skill;
import com.voidmain.pojo.Student;
import com.voidmain.pojo.Syllabus;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class AppService {

	public static int uploadStudent(String fileName,String type)
	{
		Map<String,String> map=new HashMap<String,String>();
		
		int result=1;

		ArrayList dataHolder = new ArrayList();

		try {

			XSSFWorkbook workbook=new XSSFWorkbook(fileName);

			/** Get the first sheet from workbook**/
			XSSFSheet mySheet = workbook.getSheetAt(0);
			/** We now need something to iterate through the cells.**/
			Iterator rowIter = mySheet.rowIterator();

			while (rowIter.hasNext()) {
				XSSFRow myRow = (XSSFRow) rowIter.next();
				Iterator cellIter = myRow.cellIterator();
				ArrayList cellStoreArrayList = new ArrayList();
				while (cellIter.hasNext()) {
					XSSFCell myCell = (XSSFCell) cellIter.next();
					cellStoreArrayList.add(myCell);
				}
				dataHolder.add(cellStoreArrayList);
			}
		} catch (Exception e) {

			result=0;
			e.printStackTrace();
		}

		try {

			ArrayList cellStoreArrayList = null;
			
			int i =0;
			//For inserting into database  
			for (i= 1; i < dataHolder.size(); i++) {
				
				try {
				
					cellStoreArrayList = (ArrayList) dataHolder.get(i);
					
					if(type.equals("Attendance"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String year=((XSSFCell) cellStoreArrayList.get(1)).toString();
						String sem=((XSSFCell) cellStoreArrayList.get(2)).toString();
						String percentage=((XSSFCell) cellStoreArrayList.get(3)).toString();
						
						Attendance attendance=new Attendance();
						attendance.setRno(rno);
						attendance.setYear(year.substring(0,year.length()-2));
						attendance.setSem(sem.substring(0,sem.length()-2));
						attendance.setPercentage(percentage.substring(0,percentage.length()-2));
						
						HibernateTemplate.addObject(attendance);
						
					}
					else if(type.equals("InternShip"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String company=((XSSFCell) cellStoreArrayList.get(1)).toString();
						String startingdate=((XSSFCell) cellStoreArrayList.get(2)).toString();
						String endingdate=((XSSFCell) cellStoreArrayList.get(3)).toString();
						String designation=((XSSFCell) cellStoreArrayList.get(4)).toString();
						
						InternShip internShip=new InternShip();
						internShip.setRno(rno);
						internShip.setCompany(company);
						internShip.setStartingdate(startingdate);
						internShip.setEndingdate(endingdate);
						internShip.setDesignation(designation);
						
						HibernateTemplate.addObject(internShip);
						
					}
					else if(type.equals("Project"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String projectname=((XSSFCell) cellStoreArrayList.get(1)).toString();
						String year=((XSSFCell) cellStoreArrayList.get(2)).toString();
						String sem=((XSSFCell) cellStoreArrayList.get(3)).toString();
						
						Project project=new Project();
						project.setRno(rno);
						project.setProjectname(projectname);
						project.setYear(year);
						project.setSem(sem.substring(0,sem.length()-2));
						
						HibernateTemplate.addObject(project);
						
					}
					else if(type.equals("SemResult"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String sgpa=((XSSFCell) cellStoreArrayList.get(1)).toString();
						String year=((XSSFCell) cellStoreArrayList.get(2)).toString();
						String sem=((XSSFCell) cellStoreArrayList.get(3)).toString();
						
						SemResult semResult=new SemResult();
						semResult.setRno(rno);
						semResult.setSgpa(sgpa.substring(0,sgpa.length()-2));
						semResult.setYear(year.substring(0,year.length()-2));
						semResult.setSem(sem.substring(0,sem.length()-2));
						
						HibernateTemplate.addObject(semResult);
						
					}
					else if(type.equals("Skill"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String skilslist=((XSSFCell) cellStoreArrayList.get(1)).toString();
						
						Skill skill=new Skill();
						skill.setRno(rno);
						skill.setSkilslist(skilslist);
						
						HibernateTemplate.addObject(skill);
						
					}
					else if(type.equals("ExtraCircularActivity"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String activity=((XSSFCell) cellStoreArrayList.get(1)).toString();
						String level=((XSSFCell) cellStoreArrayList.get(2)).toString();
						String medaltype=((XSSFCell) cellStoreArrayList.get(3)).toString();
						
						ExtraCircularActivity extraCircularActivity=new ExtraCircularActivity();
						extraCircularActivity.setRno(rno);
						extraCircularActivity.setActivity(activity);
						extraCircularActivity.setLevel(level);
						extraCircularActivity.setMedaltype(medaltype);
						
						HibernateTemplate.addObject(extraCircularActivity);
						
					}
					else if(type.equals("CGPA"))
					{
						String rno=((XSSFCell) cellStoreArrayList.get(0)).toString();
						String cgpa=((XSSFCell) cellStoreArrayList.get(1)).toString();
						
						Student student=HibernateDAO.getStudentById(rno);
						student.setCgpa(cgpa.substring(0,cgpa.length()-2));
						
						HibernateTemplate.updateObject(student);
						
					}
					
					
					else if(type.equals("Assignment"))
					{
						Assignment assignment=new Assignment();
						
						assignment.setSubject(((XSSFCell) cellStoreArrayList.get(0)).toString());
						assignment.setBranch(((XSSFCell) cellStoreArrayList.get(1)).toString());
						
						String year=((XSSFCell) cellStoreArrayList.get(2)).toString();
						assignment.setYear(year.substring(0,year.length()-2));
						
						assignment.setSection(((XSSFCell) cellStoreArrayList.get(3)).toString());
						
						HibernateTemplate.updateObject(assignment);
						
					}
					else if(type.equals("CourseVideos"))
					{
						CourseVideos videos=new CourseVideos();
						
						videos.setSubject(((XSSFCell) cellStoreArrayList.get(0)).toString());
						videos.setDescription(((XSSFCell) cellStoreArrayList.get(1)).toString());
						videos.setUrl(((XSSFCell) cellStoreArrayList.get(2)).toString());
						
						HibernateTemplate.updateObject(videos);
						
					}
					else if(type.equals("Syllabus"))
					{
						Syllabus syllabus=new Syllabus();
						
						syllabus.setSubject(((XSSFCell) cellStoreArrayList.get(0)).toString());
						syllabus.setDownloadLink(((XSSFCell) cellStoreArrayList.get(1)).toString());
						
						HibernateTemplate.updateObject(syllabus);
						
					}
					
				} catch (Exception e) {
					
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			result=0;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}



