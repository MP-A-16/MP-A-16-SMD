package com.voidmain.servlets;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileItemFactory;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

import com.voidmain.dao.HibernateTemplate;
import com.voidmain.pojo.Assignment_Result;

@WebServlet("/UploadFileServlet")
public class UploadFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String uploadFilename = "";
	String assignment;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean isUploaded = false;

		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);

		if (isMultipart) {
			
			// Root Directory.
			String uploadRootPath = request.getServletContext().getRealPath("")+"/documents/";
			System.out.println("uploadRootPath=" + uploadRootPath);

			File uploadRootDir = new File(uploadRootPath);
			// Create directory if it not exists.
			if (!uploadRootDir.exists()) {
				uploadRootDir.mkdirs();
			}
			
			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();

			// Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);

			try {
				// Parse the request
				List<FileItem> items = upload.parseRequest(new ServletRequestContext(request));

				for (FileItem item : items) {

					// processes only fields that are not form fields
					if (!item.isFormField()) {

						//this will be true if file field is found in the List
						try {
							uploadFilename=item.getName();
							item.write(new File(uploadRootPath+item.getName()));
							isUploaded=true;
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else
					{
						String fieldName = item.getFieldName();
						String fieldValue = item.getString();
						
						if(fieldName.endsWith("assignment"))
						{
							assignment=fieldValue;
						}
					}
				}
				
			}//try
			catch (FileUploadException e) {
				e.printStackTrace();
			}

		}

		if(isUploaded)
		{
			Assignment_Result assignment_Result=new Assignment_Result();
			
			assignment_Result.setAssignment_id(Integer.parseInt(assignment));
			assignment_Result.setDocument(uploadFilename);
			assignment_Result.setRno((String)request.getSession().getAttribute("username"));
			assignment_Result.setScore("Pending");
			
			int result=HibernateTemplate.addObject(assignment_Result);

			if(result==1)
			{
				response.sendRedirect("viewassignments.jsp?status=success");
			}
			else
			{
				response.sendRedirect("viewassignments.jsp?status=failed");
			}
		}
		else
		{
			response.sendRedirect("uploadsheet.jsp?status=failed");
		}
	}
}
