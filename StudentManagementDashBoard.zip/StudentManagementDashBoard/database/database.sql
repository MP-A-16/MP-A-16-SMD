/*
SQLyog Community v11.51 (32 bit)
MySQL - 5.5.42 : Database - studentmanagementdashboard
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`studentmanagementdashboard` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `studentmanagementdashboard`;

/*Table structure for table `assignment` */

DROP TABLE IF EXISTS `assignment`;

CREATE TABLE `assignment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` varchar(255) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `assignment` */

insert  into `assignment`(`id`,`branch`,`section`,`subject`,`year`) values (2,'cse','A','OOOPS','4');

/*Table structure for table `assignment_result` */

DROP TABLE IF EXISTS `assignment_result`;

CREATE TABLE `assignment_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `document` varchar(255) DEFAULT NULL,
  `rno` varchar(255) DEFAULT NULL,
  `score` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `assignment_result` */

insert  into `assignment_result`(`id`,`assignment_id`,`document`,`rno`,`score`) values (3,2,'requirements.txt','21321a1201','50');

/*Table structure for table `attendance` */

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `percentage` varchar(255) DEFAULT NULL,
  `rno` varchar(255) DEFAULT NULL,
  `sem` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `attendance` */

insert  into `attendance`(`id`,`percentage`,`rno`,`sem`,`year`) values (1,'88','21321a1201','1','4');

/*Table structure for table `coursevideos` */

DROP TABLE IF EXISTS `coursevideos`;

CREATE TABLE `coursevideos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `coursevideos` */

/*Table structure for table `extracircularactivity` */

DROP TABLE IF EXISTS `extracircularactivity`;

CREATE TABLE `extracircularactivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `medaltype` varchar(255) DEFAULT NULL,
  `rno` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `extracircularactivity` */

insert  into `extracircularactivity`(`id`,`activity`,`level`,`medaltype`,`rno`) values (1,'Cricket','21321A1201','Cricket','21321a1201');

/*Table structure for table `internship` */

DROP TABLE IF EXISTS `internship`;

CREATE TABLE `internship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `endingdate` varchar(255) DEFAULT NULL,
  `rno` varchar(255) DEFAULT NULL,
  `startingdate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `internship` */

insert  into `internship`(`id`,`company`,`designation`,`endingdate`,`rno`,`startingdate`) values (1,'TCS','Developer','10-Sep-2024','21321a1201','10-Mar-2024');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`username`,`password`,`role`) values ('21321a1201','Srinu123','student'),('admin123','Admin123','admin'),('nagasrinu482@gmail.com','21321a1201','parent'),('praveen123','Praveen123','mentor');

/*Table structure for table `mentor` */

DROP TABLE IF EXISTS `mentor`;

CREATE TABLE `mentor` (
  `username` varchar(255) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `mentor` */

insert  into `mentor`(`username`,`department`,`section`,`year`) values ('praveen123','cse','A','4');

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mdate` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `postedby` varchar(255) DEFAULT NULL,
  `postedto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `message` */

insert  into `message`(`id`,`mdate`,`message`,`postedby`,`postedto`) values (1,'Mon Sep 23 10:27:57 IST 2024','hi sir','prasad123','srinu123'),(3,'Mon Sep 23 16:33:35 IST 2024','gasdfsadf','srinu123','prasad123'),(5,'Tue Sep 24 14:34:52 IST 2024','Hi are you attended today?','admin123','praveen123'),(6,'Tue Sep 24 14:35:57 IST 2024','yes sir','praveen123','admin123'),(7,'Tue Sep 24 15:59:08 IST 2024','hrasdfsadfasdfas by praent','nagasrinu482@gmail.com','praveen123'),(8,'Tue Sep 24 15:59:43 IST 2024','asdfasdfsadf','praveen123','nagasrinu482@gmail.com');

/*Table structure for table `notification` */

DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `notification` */

insert  into `notification`(`id`,`date`,`description`,`title`) values (2,'Tue Sep 24 15:44:27 IST 2024','asdfasfsadf','hollidays');

/*Table structure for table `project` */

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projectname` varchar(255) DEFAULT NULL,
  `rno` varchar(255) DEFAULT NULL,
  `sem` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `project` */

insert  into `project`(`id`,`projectname`,`rno`,`sem`,`year`) values (1,'Student DashBoard','21321a1201','1','4');

/*Table structure for table `semresult` */

DROP TABLE IF EXISTS `semresult`;

CREATE TABLE `semresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rno` varchar(255) DEFAULT NULL,
  `sem` varchar(255) DEFAULT NULL,
  `sgpa` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `semresult` */

insert  into `semresult`(`id`,`rno`,`sem`,`sgpa`,`year`) values (1,'21321a1201','1','77','4');

/*Table structure for table `skill` */

DROP TABLE IF EXISTS `skill`;

CREATE TABLE `skill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rno` varchar(255) DEFAULT NULL,
  `skilslist` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `skill` */

insert  into `skill`(`id`,`rno`,`skilslist`) values (1,'21321a1201','Java,PHP,Python');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `rno` varchar(255) NOT NULL,
  `cgpa` varchar(255) DEFAULT NULL,
  `currentyear` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `review` varchar(255) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `parentemail` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`rno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`rno`,`cgpa`,`currentyear`,`department`,`name`,`review`,`section`,`parentemail`) values ('21321a1201','78','4','cse','Abc','Good','A','nagasrinu482@gmail.com');

/*Table structure for table `syllabus` */

DROP TABLE IF EXISTS `syllabus`;

CREATE TABLE `syllabus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `downloadLink` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `syllabus` */

insert  into `syllabus`(`id`,`downloadLink`,`subject`) values (4,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjw6J4puL_4IJaQdVjZhc1efdJyjCMplDhiA&s','Java'),(5,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjw6J4puL_4IJaQdVjZhc1efdJyjCMplDhiA&s','python');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
